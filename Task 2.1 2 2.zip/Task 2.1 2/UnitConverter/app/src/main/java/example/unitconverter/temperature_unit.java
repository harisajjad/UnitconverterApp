package com.example.unitconverter;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.util.Arrays;

public class temperature_unit extends AppCompatActivity {

    CardView con_fromUnit, con_toUnit, convert;
    RelativeLayout mCLayout;
    String fromUnit = "Celcius";
    String toUnit = "Farenheit";
    TextView t_f_Unit, t_t_Unit;
    EditText editfromUnit, edittoUnit;
    final String[] values = new String[]{
            "Celcius",
            "Fahrenheit",
            "Kelvin",

    };

    //celcius
    private String celtoKelvin(double c) {
        double k = c + 273.15;
        return String.valueOf(k);
    }

    private String celtoFarenheit(double c) {
        double f = (c * 9 / 5) + 32;
        return String.valueOf(f);
    }

    //fahrenheit
    private String fahtoKelvin(double f) {
        double k = 273.5 + ((f - 32.0) * (5.0 / 9.0));
        return String.valueOf(k);
    }

    private String fahtoCelcius(double f) {
        double c = (f - 32) * 5 / 9;
        return String.valueOf(c);
    }

    //Kelvin


    private String keltoCelcius(double k) {
        double c = k - 273.15;
        return String.valueOf(c);
    }

    private String keltoFahrenheit(double k) {
        double f = (k - 273.15) * 1.8 + 32;
        return String.valueOf(f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature_converter);

        con_fromUnit = findViewById(R.id.fromUnit);
        con_toUnit = findViewById(R.id.toUnit);
        convert = findViewById(R.id.convert);

        mCLayout = findViewById(R.id.temp_relativeLayout);

        t_f_Unit = findViewById(R.id.t_f_Unit);
        t_t_Unit = findViewById(R.id.t_t_Unit);

        t_f_Unit.setText(values[0]);
        t_t_Unit.setText(values[0]);

        editfromUnit = findViewById(R.id.editfromUnit);
        edittoUnit = findViewById(R.id.edittoUnit);

        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tempInput = editfromUnit.getText().toString();
                if (tempInput.equals("") || tempInput == null) {
                    editfromUnit.setError("Please enter some value");
                } else {
                    if (t_f_Unit.getText().toString().equals(values[0])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(tempInput);
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(celtoFarenheit(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(celtoKelvin(Double.parseDouble(tempInput)));
                        }
                    } else if (t_f_Unit.getText().toString().equals(values[1])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(fahtoCelcius(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(tempInput);
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(fahtoKelvin(Double.parseDouble(tempInput)));
                        }
                    } else if (t_f_Unit.getText().toString().equals(values[2])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(keltoCelcius(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(keltoFahrenheit(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(tempInput);
                        }
                    }
                }
            }
        });

        con_toUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(temperature_unit.this);
                builder.setTitle("choose Unit");

                final String[] flowers = new String[]{
                        "Celcius",
                        "Fahrenheit",
                        "Kelvin",
                };

                builder.setSingleChoiceItems(
                        flowers, // Items list
                        -1, // Index of checked item (-1 = no selection)
                        new DialogInterface.OnClickListener() // Item click listener
                        {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // Get the alert dialog selected item's text
                                String selectedItem = Arrays.asList(flowers).get(i);
                                toUnit = selectedItem;
                                t_t_Unit.setText(toUnit);

                            }
                        });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Just dismiss the alert dialog after selection
                        // Or do something now
                        dialogInterface.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();

                // Finally, display the alert dialog
                dialog.show();

            }
        });

        con_fromUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(temperature_unit.this);
                builder.setTitle("choose Unit");

                final String[] flowers = new String[]{
                        "Celcius",
                        "Fahrenheit",
                        "Kelvin",

                };

                builder.setSingleChoiceItems(
                        flowers, // Items list
                        -1, // Index of checked item (-1 = no selection)
                        new DialogInterface.OnClickListener() // Item click listener
                        {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // Get the alert dialog selected item's text
                                String selectedItem = Arrays.asList(flowers).get(i);
                                fromUnit = selectedItem;
                                t_f_Unit.setText(fromUnit);

                            }
                        });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Just dismiss the alert dialog after selection
                        // Or do something now
                        dialogInterface.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();

                // Finally, display the alert dialog
                dialog.show();

            }
        });

    }





}