package com.example.unitconverter;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.util.Arrays;

public class length_unit extends AppCompatActivity {
    CardView con_fromUnit, con_toUnit, convert;
    RelativeLayout mCLayout;
    String fromUnit = "inch";
    String toUnit = "Inch";
    TextView t_f_Unit, t_t_Unit;
    EditText editfromUnit, edittoUnit;
    final String[] values = new String[]{
            "Inch",
            "Foot",
            "Yard",
            "Mile",
            "CM",
            "KM",
    };

    //Inch
    private String intoFoot(double i) {
        double fo = i / 12;
        return String.valueOf(fo);
    }

    private String intoYard(double i) {
        double ya = i / 36;
        return String.valueOf(ya);
    }

    private String intoMile(double i) {
        double mi = i / 63360;
        return String.valueOf(mi);
    }

    private String intoCM(double i) {
        double cm = i * 2.54;
        return String.valueOf(cm);
    }

    private String intoKM(double i) {
        double km = i / 39370;
        return String.valueOf(km);
    }


    //Foot
    private String fotoInch(double fo) {
        double i = fo * 12;
        return String.valueOf(i);
    }

    private String fotoYard(double fo) {
        double ya = fo / 3;
        return String.valueOf(ya);
    }

    private String fotoMile(double fo) {
        double mi = fo / 5280;
        return String.valueOf(mi);
    }

    private String fotoCM(double fo) {
        double cm = fo * 30.48;
        return String.valueOf(cm);
    }

    private String fotoKM(double fo) {
        double km = fo / 3281;
        return String.valueOf(km);
    }


    //Yard
    private String YatoInch(double ya) {
        double i = ya * 36;
        return String.valueOf(i);
    }

    private String YatoFoot(double ya) {
        double fo = ya * 3;
        return String.valueOf(fo);
    }

    private String YatoMile(double ya) {
        double mi = ya / 1760;
        return String.valueOf(mi);
    }

    private String YatoCM(double ya) {
        double cm = ya * 91.44;
        return String.valueOf(cm);
    }

    private String YatoKM(double ya) {
        double km = ya / 1094;
        return String.valueOf(km);
    }


    //Mile
    private String mitoInch(double mi) {
        double i = mi * 63360;
        return String.valueOf(i);
    }

    private String mitoFoot(double mi) {
        double fo = mi * 5280;
        return String.valueOf(fo);
    }

    private String mitoYard(double mi) {
        double ya = mi * 1760;
        return String.valueOf(ya);
    }

    private String mitoCM(double mi) {
        double cm = mi * 160900;
        return String.valueOf(cm);
    }

    private String mitoKM(double mi) {
        double km = mi * 1.609344;
        return String.valueOf(km);
    }


    //CM
    private String cmtoInch(double cm) {
        double i = cm / 2.54;
        return String.valueOf(i);
    }

    private String cmtoFoot(double cm) {
        double fo = cm / 30.48;
        return String.valueOf(fo);
    }

    private String cmtoYard(double cm) {
        double ya = cm / 91.44;
        return String.valueOf(ya);
    }

    private String cmtomile(double cm) {
        double mi = cm / 160900;
        return String.valueOf(mi);
    }

    private String cmtoKM(double cm) {
        double km = cm / 100000;
        return String.valueOf(km);
    }


    //KM
    private String kmtoInch(double km) {
        double i = km * 39370.1;
        return String.valueOf(i);
    }

    private String kmtoFoot(double km) {
        double fo = km * 3280.8;
        return String.valueOf(fo);
    }

    private String kmtoYard(double km) {
        double ya = km * 1094;
        return String.valueOf(ya);
    }

    private String kmtoMile(double km) {
        double mi = km / 1.609;
        return String.valueOf(mi);
    }

    private String kmtoCM(double km) {
        double cm = km * 100000;
        return String.valueOf(cm);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length_converter);

        con_fromUnit = findViewById(R.id.fromUnit);
        con_toUnit = findViewById(R.id.toUnit);
        convert = findViewById(R.id.convert);

        mCLayout = findViewById(R.id.temp_relativeLayout);

        t_f_Unit = findViewById(R.id.t_f_Unit);
        t_t_Unit = findViewById(R.id.t_t_Unit);

        t_f_Unit.setText(values[0]);
        t_t_Unit.setText(values[0]);

        editfromUnit = findViewById(R.id.editfromUnit);
        edittoUnit = findViewById(R.id.edittoUnit);

        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tempInput = editfromUnit.getText().toString();
                if (tempInput.equals("") || tempInput == null) {
                    editfromUnit.setError("Please enter some value");
                } else {
                    if (t_f_Unit.getText().toString().equals(values[0])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(tempInput);
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(intoFoot(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(intoYard(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(intoMile(Double.parseDouble(tempInput)));
                        }  else if (t_t_Unit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(intoCM(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[5])) {
                            edittoUnit.setText(intoKM(Double.parseDouble(tempInput)));
                        }

                    } else if (t_f_Unit.getText().toString().equals(values[1])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(fotoInch(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(tempInput);
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(fotoYard(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(fotoMile(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(fotoCM(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[5])) {
                            edittoUnit.setText(fotoKM(Double.parseDouble(tempInput)));
                        }
                    } else if (t_f_Unit.getText().toString().equals(values[2])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(YatoInch(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(YatoFoot(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(tempInput);
                        } else if (t_t_Unit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(YatoMile(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(YatoCM(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[5])) {
                            edittoUnit.setText(YatoKM(Double.parseDouble(tempInput)));
                        }
                    } else if (t_f_Unit.getText().toString().equals(values[3])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(mitoInch(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(mitoFoot(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(mitoYard(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(tempInput);
                        } else if (t_t_Unit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(mitoCM(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[5])) {
                            edittoUnit.setText(mitoKM(Double.parseDouble(tempInput)));
                        }
                    } else if (t_f_Unit.getText().toString().equals(values[4])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(cmtoInch(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(cmtoFoot(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(cmtoYard(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(cmtomile(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(tempInput);
                        } else if (t_t_Unit.getText().toString().equals(values[5])) {
                            edittoUnit.setText(cmtoKM(Double.parseDouble(tempInput)));
                        }
                    } else if (t_f_Unit.getText().toString().equals(values[5])) {
                        if (t_t_Unit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(kmtoInch(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(kmtoFoot(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(kmtoYard(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(kmtoMile(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(kmtoCM(Double.parseDouble(tempInput)));
                        } else if (t_t_Unit.getText().toString().equals(values[5])) {
                            edittoUnit.setText(tempInput);
                        }
                    }
                }
            }
        });

        con_toUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(length_unit.this);
                builder.setTitle("choose Unit");

                final String[] flowers = new String[]{
                        "Inch",
                        "Foot",
                        "Yard",
                        "Mile",
                        "CM",
                        "KM",
                };

                builder.setSingleChoiceItems(
                        flowers, // Items list
                        -1, // Index of checked item (-1 = no selection)
                        new DialogInterface.OnClickListener() // Item click listener
                        {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // Get the alert dialog selected item's text
                                String selectedItem = Arrays.asList(flowers).get(i);
                                toUnit = selectedItem;
                                t_t_Unit.setText(toUnit);

                            }
                        });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Just dismiss the alert dialog after selection
                        // Or do something now
                        dialogInterface.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();

                // Finally, display the alert dialog
                dialog.show();

            }
        });

        con_fromUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(length_unit.this);
                builder.setTitle("choose Unit");

                final String[] flowers = new String[]{
                        "Inch",
                        "Foot",
                        "Yard",
                        "Mile",
                        "CM",
                        "KM",
                };

                builder.setSingleChoiceItems(
                        flowers, // Items list
                        -1, // Index of checked item (-1 = no selection)
                        new DialogInterface.OnClickListener() // Item click listener
                        {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // Get the alert dialog selected item's text
                                String selectedItem = Arrays.asList(flowers).get(i);
                                fromUnit = selectedItem;
                                t_f_Unit.setText(fromUnit);

                            }
                        });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Just dismiss the alert dialog after selection
                        // Or do something now
                        dialogInterface.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();

                // Finally, display the alert dialog
                dialog.show();

            }
        });

    }

}