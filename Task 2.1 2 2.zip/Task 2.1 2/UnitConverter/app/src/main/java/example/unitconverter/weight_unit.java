package com.example.unitconverter;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.util.Arrays;

public class weight_unit extends AppCompatActivity {

    CardView con_fromUnit, con_toUnit, convert;
    RelativeLayout mCLayout;
    String fromUnit = "Kilogram";
    String toUnit = "Kilogram";
    TextView textfromUnit, texttoUnit;
    EditText editfromUnit, edittoUnit;
    final String[] values = new String[]{
            "Kilogram",
            "Gram",
            "Pound ",
            "Ounce",
            "Ton",
    };

    //Kilogram

    private String kilotoGram(double k) {
        double g = k * 1000;
        return String.valueOf(g);
    }

    private String kilotoPound(double k) {
        double p = k * 2.20462;
        return String.valueOf(p);
    }

    private String kilotoOunce(double k) {
        double o = k * 35.274;
        return String.valueOf(o);
    }

    private String kilotoTon(double k) {
        double t = k / 1000;
        return String.valueOf(t);
    }


    //Gram
    private String grtoKiloGram(double g) {
        double k = g * 0.001;
        return String.valueOf(k);
    }

    private String grtoPound(double g) {
        double p = g / 453.6;
        return String.valueOf(p);
    }

    private String grtoOunce(double g) {
        double o = g / 28.35;
        return String.valueOf(o);
    }

    private String grtoTon(double g) {
        double t = g / 1000000;
        return String.valueOf(t);
    }


    //Pound
    private String potoKiloGram(double p) {
        double k = p * 0.453592;
        return String.valueOf(k);
    }

    private String PotoGRAM(double p) {
        double g = p * 453.59237;
        return String.valueOf(g);
    }

    private String PotoOunce(double p) {
        double o = p * 16;
        return String.valueOf(o);
    }

    private String PotoTon(double p) {
        double t = p / 2205;
        return String.valueOf(t);
    }


    //Ounce
    private String OutoKiloGram(double o) {
        double k = o / 35.274;
        return String.valueOf(k);
    }

    private String OutoGram(double o) {
        double g = o * 28.3495;
        return String.valueOf(g);
    }

    private String OutoPound(double o) {
        double p = o / 16;
        return String.valueOf(p);
    }

    private String OutoTon(double o) {
        double t = o / 35270;
        return String.valueOf(t);
    }

    //Ton
    private String TontoKiloGram(double t) {
        double k = t * 1000;
        return String.valueOf(k);
    }

    private String TontoGram(double t) {
        double g = t * 907184.74;
        return String.valueOf(g);
    }

    private String TontoPound(double t) {
        double p = t * 2205;
        return String.valueOf(p);
    }

    private String TontoOunce(double t) {
        double o = t * 35270;
        return String.valueOf(o);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_converter);

        con_fromUnit = findViewById(R.id.fromUnit);
        con_toUnit = findViewById(R.id.toUnit);
        convert = findViewById(R.id.convert);

        mCLayout = findViewById(R.id.temp_relativeLayout);

        textfromUnit = findViewById(R.id.textfromUnit);
        texttoUnit = findViewById(R.id.texttoUnit);

        textfromUnit.setText(values[0]);
        texttoUnit.setText(values[0]);

        editfromUnit = findViewById(R.id.editfromUnit);
        edittoUnit = findViewById(R.id.edittoUnit);

        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tempInput = editfromUnit.getText().toString();
                if (tempInput.equals("") || tempInput == null) {
                    editfromUnit.setError("Please enter some value");
                } else {
                    if (textfromUnit.getText().toString().equals(values[0])) {
                        if (texttoUnit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(tempInput);
                        } else if (texttoUnit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(kilotoGram(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(kilotoPound(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(kilotoOunce(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(kilotoTon(Double.parseDouble(tempInput)));
                        }
                    } else if (textfromUnit.getText().toString().equals(values[1])) {
                        if (texttoUnit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(grtoKiloGram(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(tempInput);
                        } else if (texttoUnit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(grtoPound(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(grtoOunce(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(grtoTon(Double.parseDouble(tempInput)));
                        }
                    } else if (textfromUnit.getText().toString().equals(values[2])) {
                        if (texttoUnit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(potoKiloGram(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(PotoGRAM(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(tempInput);
                        } else if (texttoUnit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(PotoOunce(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(PotoTon(Double.parseDouble(tempInput)));
                        }
                    } else if (textfromUnit.getText().toString().equals(values[3])) {
                        if (texttoUnit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(OutoKiloGram(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(OutoGram(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(OutoPound(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(tempInput);
                        } else if (texttoUnit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(OutoTon(Double.parseDouble(tempInput)));
                        }
                    } else if (textfromUnit.getText().toString().equals(values[4])) {
                        if (texttoUnit.getText().toString().equals(values[0])) {
                            edittoUnit.setText(TontoKiloGram(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[1])) {
                            edittoUnit.setText(TontoGram(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[2])) {
                            edittoUnit.setText(TontoOunce(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[3])) {
                            edittoUnit.setText(TontoPound(Double.parseDouble(tempInput)));
                        } else if (texttoUnit.getText().toString().equals(values[4])) {
                            edittoUnit.setText(tempInput);
                        }
                    }
                }
            }
        });


        con_toUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(weight_unit.this);
                builder.setTitle("choose Unit");

                final String[] flowers = new String[]{
                        "Kilogram",
                        "Gram",
                        "Pound ",
                        "Ounce",
                        "Ton",

                };

                builder.setSingleChoiceItems(
                        flowers, // Items list
                        -1, // Index of checked item (-1 = no selection)
                        new DialogInterface.OnClickListener() // Item click listener
                        {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // Get the alert dialog selected item's text
                                String selectedItem = Arrays.asList(flowers).get(i);
                                toUnit = selectedItem;
                                texttoUnit.setText(toUnit);

                            }
                        });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Just dismiss the alert dialog after selection
                        // Or do something now
                        dialogInterface.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();

                // Finally, display the alert dialog
                dialog.show();

            }
        });

        con_fromUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(weight_unit.this);
                builder.setTitle("choose Unit");

                final String[] flowers = new String[]{
                        "Kilogram",
                        "Gram",
                        "Pound ",
                        "Ounce",
                        "Ton",


                };

                builder.setSingleChoiceItems(
                        flowers, // Items list
                        -1, // Index of checked item (-1 = no selection)
                        new DialogInterface.OnClickListener() // Item click listener
                        {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // Get the alert dialog selected item's text
                                String selectedItem = Arrays.asList(flowers).get(i);
                                fromUnit = selectedItem;
                                textfromUnit.setText(fromUnit);

                            }
                        });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Just dismiss the alert dialog after selection
                        // Or do something now
                        dialogInterface.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();

                // Finally, display the alert dialog
                dialog.show();

            }
        });
    }


}